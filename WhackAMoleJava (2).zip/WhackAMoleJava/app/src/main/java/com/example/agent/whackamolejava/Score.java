package com.example.agent.whackamolejava;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Score extends AppCompatActivity {
    private String scoring;
    private TextView score;
    private Button redo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        score = (TextView) findViewById(R.id.score);
        redo = (Button) findViewById(R.id.redo);
        Bundle bn = getIntent().getExtras();
        String scoring = bn.getString("score");
        score.setText(scoring);
        redo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Score.this, MainActivity.class));
            }
        });

    }
}
