package com.example.agent.whackamolejava;
//"Use Android Studio and Java (or Kotlin if you prefer) to design a Whack a mole game. Here are the detailed requirements:"
//      "1) When user launches the app, the initial screen allows the user to choose from three options:  [6 points]"
//    "2) After the user choose one of the three options, the 2nd screen shows the number of holes as per the user's selection. A score text should display on the top of the screen to track the user's score. [4 points]"
//   "3) On the 2nd screen, a mole shows randomly at any hole location, the user can tab / click on the mole to 'whack' it. Each time the user clicks on the mole, the score should increase by 1.  [16 points]"
// "4) Your app should set a time of 60 seconds or 90 seconds (your choice) to end the game. When the time is up, the 3rd screen opens, shows the final score and two options for the user either to exit the game or to restart.  [9 points]"
//"Extra credit [1 point] : Sound"




import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;

import java.util.Random;


public class GamePlay extends AppCompatActivity {
    private ImageView ImageView1;
    private ImageView ImageView2;
    private ImageView ImageView3;
    private ImageView ImageView4;
    private ImageView ImageView5;
    private ImageView ImageView6;
    private ImageView ImageView7;
    private ImageView ImageView8;
    private ImageView ImageView9;
    private ImageView ImageView10;
    private ImageView ImageView11;
    private ImageView ImageView12;
    private ImageView ImageView13;
    private ImageView ImageView14;
    private ImageView ImageView15;
    private ImageView ImageView16;
    private ImageView ImageView17;
    private ImageView ImageView18;
    private ImageView ImageView19;
    private ImageView ImageView20;
    private Integer random_2;
    private Integer random_1;
    private Integer random_3;
    private Integer random_4;

    private TextView TimerT;
    private String score;
    private int scoring;
    private int fd;
    private TextView ScoreView;
    private TextView values;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_play);
        Bundle bn = getIntent().getExtras();
        Integer vals = bn.getInt("row");
        ConstraintLayout currentLayout =(ConstraintLayout) findViewById(R.id.borp);
        currentLayout.setBackgroundResource(R.drawable.back);



        ImageView1 = (ImageView) findViewById(R.id.imageView1);
        ImageView2 = (ImageView) findViewById(R.id.imageView2);
        ImageView3 = (ImageView) findViewById(R.id.imageView3);
        ImageView4 = (ImageView) findViewById(R.id.imageView4);
        ImageView5 = (ImageView) findViewById(R.id.imageView5);
        ImageView6 = (ImageView) findViewById(R.id.imageView6);
        ImageView7 = (ImageView) findViewById(R.id.imageView7);
        ImageView8 = (ImageView) findViewById(R.id.imageView8);
        ImageView9 = (ImageView) findViewById(R.id.imageView9);
        ImageView10 = (ImageView) findViewById(R.id.imageView10);
        ImageView11 = (ImageView) findViewById(R.id.imageView11);
        ImageView12 = (ImageView) findViewById(R.id.imageView12);
        ImageView13 = (ImageView) findViewById(R.id.imageView13);
        ImageView14 = (ImageView) findViewById(R.id.imageView14);
        ImageView15 = (ImageView) findViewById(R.id.imageView15);
        ImageView16 = (ImageView) findViewById(R.id.imageView16);
        ImageView17 = (ImageView) findViewById(R.id.imageView17);
        ImageView18 = (ImageView) findViewById(R.id.imageView18);
        ImageView19 = (ImageView) findViewById(R.id.imageView19);
        ImageView20 = (ImageView) findViewById(R.id.imageView20);
        ScoreView = (TextView) findViewById(R.id.ScoreView);
        TimerT = (TextView) findViewById(R.id.TimerT);
        scoring=0;
        ScoreView.setText(Integer.toString(scoring));

        ImageView1.setImageResource(R.drawable.fram1);
        ImageView2.setImageResource(R.drawable.fram1);
        ImageView3.setImageResource(R.drawable.fram1);
        ImageView4.setImageResource(R.drawable.fram1);
        ImageView5.setImageResource(R.drawable.fram1);
        ImageView6.setImageResource(R.drawable.fram1);
        ImageView7.setImageResource(R.drawable.fram1);
        ImageView8.setImageResource(R.drawable.fram1);
        ImageView9.setImageResource(R.drawable.fram1);
        ImageView10.setImageResource(R.drawable.fram1);
        ImageView11.setImageResource(R.drawable.fram1);
        ImageView12.setImageResource(R.drawable.fram1);
        ImageView13.setImageResource(R.drawable.fram1);
        ImageView14.setImageResource(R.drawable.fram1);
        ImageView15.setImageResource(R.drawable.fram1);
        ImageView16.setImageResource(R.drawable.fram1);
        ImageView17.setImageResource(R.drawable.fram1);
        ImageView18.setImageResource(R.drawable.fram1);
        ImageView19.setImageResource(R.drawable.fram1);
        ImageView20.setImageResource(R.drawable.fram1);
        fd=750;

        if (vals==2){


            ImageView7.setVisibility(View.INVISIBLE);
            ImageView8.setVisibility(View.INVISIBLE);
            ImageView9.setVisibility(View.INVISIBLE);
            ImageView10.setVisibility(View.INVISIBLE);
            ImageView11.setVisibility(View.INVISIBLE);
            ImageView12.setVisibility(View.INVISIBLE);
            ImageView13.setVisibility(View.INVISIBLE);
            ImageView14.setVisibility(View.INVISIBLE);
            ImageView15.setVisibility(View.INVISIBLE);
            ImageView16.setVisibility(View.INVISIBLE);
            ImageView17.setVisibility(View.INVISIBLE);
            ImageView18.setVisibility(View.INVISIBLE);
            ImageView19.setVisibility(View.INVISIBLE);
            ImageView20.setVisibility(View.INVISIBLE);
            fd=400;
        }

        if (vals==3){
            ImageView13.setVisibility(View.GONE);
            ImageView14.setVisibility(View.GONE);
            ImageView15.setVisibility(View.GONE);
            ImageView16.setVisibility(View.GONE);
            ImageView17.setVisibility(View.GONE);
            ImageView18.setVisibility(View.GONE);
            ImageView19.setVisibility(View.GONE);
            ImageView20.setVisibility(View.GONE);
            fd=550;

        }









        new CountDownTimer(60000,fd) {

            public void onTick(long millisUntilFinished) {
                TimerT.setText("Time remaining: " + millisUntilFinished / 1000);
                Bundle bn = getIntent().getExtras();
                Integer xl = bn.getInt("row");


                if (xl==2) {
                    random_1 = new Random().nextInt(7);


                    random_2 = new Random().nextInt(7);

                    while (random_1 == random_2) {
                        random_2 = new Random().nextInt(7);
                    }
                    random_3=0;
                    random_4=0;

                }

                if (xl==3){
                    random_1 = new Random().nextInt(13);


                    random_2 = new Random().nextInt(13);

                    while (random_1 == random_2) {
                        random_2 = new Random().nextInt(13);
                    }
                    random_3 = new Random().nextInt(13);
                    while (random_3 == random_2 || random_3 == random_1) {
                        random_3 = new Random().nextInt(13);
                    }
                    random_4=0;
                }

                if (xl==4){
                    random_1 = new Random().nextInt(21);
                    random_2 = new Random().nextInt(21);
                    while (random_1 == random_2) {
                        random_2 = new Random().nextInt(21);
                    }
                    random_3 = new Random().nextInt(21);
                    while (random_3 == random_2 || random_3 == random_1) {
                        random_3 = new Random().nextInt(21);}

                    random_4 = new Random().nextInt(21);
                    while (random_4 == random_2 || random_4 == random_1|| random_3 == random_4) {
                        random_4 = new Random().nextInt(21);
                    }}



                ImageView1.setImageResource(R.drawable.fram1);
                ImageView2.setImageResource(R.drawable.fram1);
                ImageView3.setImageResource(R.drawable.fram1);
                ImageView4.setImageResource(R.drawable.fram1);
                ImageView5.setImageResource(R.drawable.fram1);
                ImageView6.setImageResource(R.drawable.fram1);
                ImageView7.setImageResource(R.drawable.fram1);
                ImageView8.setImageResource(R.drawable.fram1);
                ImageView9.setImageResource(R.drawable.fram1);
                ImageView10.setImageResource(R.drawable.fram1);
                ImageView11.setImageResource(R.drawable.fram1);
                ImageView12.setImageResource(R.drawable.fram1);
                ImageView13.setImageResource(R.drawable.fram1);
                ImageView14.setImageResource(R.drawable.fram1);
                ImageView15.setImageResource(R.drawable.fram1);
                ImageView16.setImageResource(R.drawable.fram1);
                ImageView17.setImageResource(R.drawable.fram1);
                ImageView18.setImageResource(R.drawable.fram1);
                ImageView19.setImageResource(R.drawable.fram1);
                ImageView20.setImageResource(R.drawable.fram1);


                ImageView1.setTag("start");
                ImageView2.setTag("start");
                ImageView3.setTag("start");
                ImageView4.setTag("start");
                ImageView5.setTag("start");
                ImageView6.setTag("start");
                ImageView7.setTag("start");
                ImageView8.setTag("start");
                ImageView9.setTag("start");
                ImageView10.setTag("start");
                ImageView11.setTag("start");
                ImageView12.setTag("start");
                ImageView13.setTag("start");
                ImageView14.setTag("start");
                ImageView15.setTag("start");
                ImageView16.setTag("start");
                ImageView17.setTag("start");
                ImageView18.setTag("start");
                ImageView19.setTag("start");
                ImageView20.setTag("start");




                if (random_1 == 1 || random_2 == 1 || random_3 == 1 || random_4 == 1) {
                    ImageView1.setTag("hit_me");
                    ImageView1.setImageResource(R.drawable.fram3);
                }


                if (random_1 == 2 || random_2 == 2 || random_3 == 2 || random_4 == 2) {
                    ImageView2.setTag("hit_me");
                    ImageView2.setImageResource(R.drawable.fram3);
                }
                if (random_1 == 3 || random_2 == 3 || random_3 == 3 || random_4 == 3) {
                    ImageView3.setTag("hit_me");
                    ImageView3.setImageResource(R.drawable.fram3);
                }

                if (random_1 == 4 || random_2 == 4 || random_3 == 4 || random_4 == 4) {
                    ImageView4.setTag("hit_me");
                    ImageView4.setImageResource(R.drawable.fram3);
                }

                if (random_1==5 || random_2==5 || random_3==5 || random_4 == 5){
                    ImageView5.setTag("hit_me");
                    ImageView5.setImageResource(R.drawable.fram3);
                }

                if (random_1==6 || random_2==6 || random_3==6 || random_4 == 6){
                    ImageView6.setTag("hit_me");
                    ImageView6.setImageResource(R.drawable.fram3);
                }
                if (random_1==7 || random_2==7 || random_3==7 || random_4 == 7){
                    ImageView7.setTag("hit_me");
                    ImageView7.setImageResource(R.drawable.fram3);

                }

                if (random_1==8 || random_2==8 || random_3==8 || random_4 == 8){
                    ImageView8.setTag("hit_me");
                    ImageView8.setImageResource(R.drawable.fram3);
                }


                if (random_1 == 9 || random_2 == 9 || random_3 == 9 || random_4 == 9) {
                    ImageView9.setTag("hit_me");
                    ImageView9.setImageResource(R.drawable.fram3);
                }

                if (random_1==10 || random_2==10 || random_3==10 || random_4 == 10){
                    ImageView10.setTag("hit_me");
                    ImageView10.setImageResource(R.drawable.fram3);
                }

                if (random_1==11 || random_2==11 || random_3==11 || random_4 == 11){
                    ImageView11.setTag("hit_me");
                    ImageView11.setImageResource(R.drawable.fram3); }

                if (random_1==12 || random_2==12 || random_3==12 || random_4 == 12){
                    ImageView12.setTag("hit_me");
                    ImageView12.setImageResource(R.drawable.fram3);}

                if (random_1==13 || random_2==13 || random_3==13 || random_4 == 13){
                    ImageView13.setTag("hit_me");
                    ImageView13.setImageResource(R.drawable.fram3); }

                if (random_1==14 || random_2==14 || random_3==14 || random_4 == 14){
                    ImageView14.setTag("hit_me");
                    ImageView14.setImageResource(R.drawable.fram3);}


                if (random_1==15 || random_2==15 || random_3==15 || random_4 == 15){
                    ImageView15.setTag("hit_me");
                    ImageView15.setImageResource(R.drawable.fram3); }

                if (random_1==16 || random_2==16 || random_3==16 || random_4 == 16){
                    ImageView16.setTag("hit_me");
                    ImageView16.setImageResource(R.drawable.fram3);
                }


                if (random_1==17 || random_2==17 || random_3==17 || random_4 == 17){
                    ImageView17.setTag("hit_me");
                    ImageView17.setImageResource(R.drawable.fram3); }

                if (random_1==18 || random_2==18 || random_3==18 || random_4 == 18){
                    ImageView18.setTag("hit_me");
                    ImageView18.setImageResource(R.drawable.fram3);}

                if (random_1==19 || random_2==19 || random_3==19 || random_4 == 19){
                    ImageView19.setTag("hit_me");
                    ImageView19.setImageResource(R.drawable.fram3); }

                if (random_1==20 || random_2==20 || random_3==20 || random_4 ==20){
                    ImageView20.setTag("hit_me");
                    ImageView2.setImageResource(R.drawable.fram3);
                }

                ImageView1.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView1.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView1.setImageResource(R.drawable.fram1);
                            ImageView1.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView2.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView2.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView2.setImageResource(R.drawable.fram1);
                            ImageView2.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}
                    }
                });
                ImageView3.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView3.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView3.setImageResource(R.drawable.fram1);
                            ImageView3.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}
                    }
                });
                ImageView4.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView4.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView4.setImageResource(R.drawable.fram1);
                            ImageView4.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView5.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView5.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView5.setImageResource(R.drawable.fram1);
                            ImageView5.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView6.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView6.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView6.setImageResource(R.drawable.fram1);
                            ImageView6.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView7.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView7.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView7.setImageResource(R.drawable.fram1);
                            ImageView7.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView8.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView8.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView8.setImageResource(R.drawable.fram1);
                            ImageView8.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}
                    }
                });
                ImageView9.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView9.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView9.setImageResource(R.drawable.fram1);
                            ImageView9.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}
                    }
                });
                ImageView10.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView10.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView10.setImageResource(R.drawable.fram1);
                            ImageView10.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView11.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView11.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView11.setImageResource(R.drawable.fram1);
                            ImageView11.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView12.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView12.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView12.setImageResource(R.drawable.fram1);
                            ImageView12.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView13.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView13.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView13.setImageResource(R.drawable.fram1);
                            ImageView13.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}
                    }
                });
                ImageView14.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView14.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView14.setImageResource(R.drawable.fram1);
                            ImageView14.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView15.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView15.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView15.setImageResource(R.drawable.fram1);
                            ImageView15.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView16.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView16.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView16.setImageResource(R.drawable.fram1);
                            ImageView16.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView17.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView17.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView17.setImageResource(R.drawable.fram1);
                            ImageView17.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView18.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView18.getTag()=="start"){
                            scoring+=1;
                            ImageView18.setImageResource(R.drawable.fram1);
                            ImageView18.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView19.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView19.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView19.setImageResource(R.drawable.fram1);
                            ImageView19.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });
                ImageView20.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (ImageView20.getTag()=="hit_me"){
                            scoring+=1;
                            ImageView20.setImageResource(R.drawable.fram1);
                            ImageView20.setTag("start");
                            ScoreView.setText(Integer.toString(scoring));}

                    }
                });


            }
            public void onFinish() {
                score=Integer.toString(scoring);
                TimerT.setText("done!");
                Intent intent = new Intent(GamePlay.this, Score.class);
                intent.putExtra("score", score);
                startActivity(intent);


            }

        }.start();









    }
}
