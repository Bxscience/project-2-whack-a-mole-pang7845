package com.example.agent.whackamolejava;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btn = (Button)findViewById(R.id.row_2);
        Button btn1 = (Button)findViewById(R.id.row_3);
        Button btn2 = (Button)findViewById(R.id.row_4);

        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent game2_3 = new Intent(MainActivity.this, GamePlay.class);
                game2_3.putExtra("row",2);
                startActivity(game2_3);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent game3_4 = new Intent(MainActivity.this, GamePlay.class);
                game3_4.putExtra("row",3);
                startActivity(game3_4);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent game4_5 = new Intent(MainActivity.this, GamePlay.class);
                game4_5.putExtra("row",4);
                startActivity(game4_5);
            }
        });
    }
}
